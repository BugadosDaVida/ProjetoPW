const mysql = require('mysql');

module.exports = {
    con: mysql.createConnection({
    host: 'webitcloud.net',
    user: 'webitclo_d11',
    password:'a*9{[#w;4VTx',
    database:'webitclo_d11' 
    })
};


console.log('Connected with DB');