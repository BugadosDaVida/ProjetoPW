module.exports = function(app, passport) {

    /* write here your code */ 
    
    }