const authController = require('../controllers/auth.controller.js');

module.exports = function(app, passport) {
    // code here
}